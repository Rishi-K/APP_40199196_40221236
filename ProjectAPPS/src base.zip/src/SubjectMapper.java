public class SubjectMapper {
    private String book;
    private String subject;
    
    
    //accessor methods
    public String getBook() {
    	return this.book;
    }    
    public String getSubject() {
    	return this.subject;
    }
    
    //mutator methods
    public void setBook(String book) {
    	this.book = book;
    }
    public void setSubject(String subject) {
    	this.subject= subject;
    }
    
}
