public interface Controller {
	public boolean update();
	public boolean delete();
	public boolean read();

}
