public class BuyMapper {
    String user;
    String book;
    
    //accessor methods
    public String getBook() {
    	return this.book;
    }    
    public String getUser() {
    	return this.user;
    }
    
    //mutator methods
    public void setBook(String book) {
    	this.book = book;
    }
    public void setUser(String user) {
    	this.user= user;
    }
    
    
}
