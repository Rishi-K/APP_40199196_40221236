
public class UsersController implements Controller {

	@Override
	public boolean update() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean read() {
		// TODO Auto-generated method stub
		return false;
	}

}
